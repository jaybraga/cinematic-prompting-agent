# Cinematic Prompting — Claude Project Instructions

Use the uploaded `SKILL.md` as the governing entrypoint for cinematic image and video prompt work in this project.

Before completing a task:

1. Retrieve and follow `Agent-Guidelines.md` and `Cinematic-Prompting-Ruleset.md`.
2. Retrieve `Workflow-Guidelines.md` for prompt-package work.
3. Retrieve `references/Mood-and-Style-Framework.md` whenever mood, style, tone, brand expression, or sequence variation must be established.
4. Retrieve `references/Camera-Movement-Language.md` for every video prompt.
5. Retrieve only the relevant model sections from `references/Model-Adapters.md`.

The user's current request and explicitly approved project decisions take priority over reusable defaults. Do not invent the contents of a missing file; ask for it to be added to Project Knowledge.

Keep the workflow still-first, single-shot, approval-driven, and continuity-controlled as defined by the uploaded skill files. Keep copy-ready prompts separate from explanations and metadata.

