# Cinematic Prompting Ruleset

## Purpose of this file

This file contains the non-negotiable production and prompt-design rules. It does not define conversational style or repeat the chronological workflow.

## 1. Still-first video production

Every video shot must begin with a static version of that exact shot.

- Create and approve a start image before writing the final video prompt.
- Create a separate end image whenever the end composition, pose, product framing, transformation, reveal, focus destination, or transition must land precisely.
- Use the approved stills as visual truth for identity, composition, production design, lighting, palette, texture, and spatial relationships.
- Do not bypass this stage because a video model supports text-to-video.
- If the user explicitly changes this rule for a particular experiment, record the exception in that shot's notes.

## 2. One continuous camera shot per generated clip

- Each video prompt describes one uninterrupted camera take with no internal cut to another angle or setup.
- Do not use native multi-shot generation, automatic shot changes, or several camera setups inside one file unless the user explicitly requests it.
- Build coverage as separate clips and leave shot order, cutting, transitions, timing, and rhythm to post-production.
- A continuous camera move may change framing within a shot, but it must remain one physically coherent take.

## 3. Mood and style approval gate

- Do not build production prompts until the piece's mood, emotional promise, visual style, and anti-goals are explicit enough to direct the work.
- If those decisions are missing, propose creative lanes and obtain approval.
- Define style through visible choices: palette, lighting logic, contrast, production design, performance, composition, optics, texture, grade, movement, and pacing.
- Store the approved base direction in the production bible.
- Record scene-specific or sequence-specific departures as intentional overrides rather than weakening the base direction.

## 4. Research before inventing missing shots

- When the user lacks a usable shot list or requests visual discovery, research what is relevant to show before drafting shots or prompts.
- Define the research mandate from the communication objective, audience, approved direction, factual/cultural scope, required proof, and production constraints.
- Separate verified facts, source-backed observations, and creative hypotheses. Never turn an assumption into a campaign claim.
- Prefer authoritative and primary sources for route, product, geographic, historical, cultural, and current operational facts.
- Evaluate candidate motifs for strategic relevance, visual potential, narrative role, brand fit, feasibility, and stereotype or sensitivity risk.
- When useful, propose two or three distinct narrative routes and obtain approval before converting the selected route into a proposed shot list.
- Obtain approval of the proposed shot list before production prompts. Skip this stage when supplied visuals are already sufficient unless the user requests enrichment or verification.

## 5. Per-Shot Direction Check before drafting

- Do not write the first static prompt for a shot until its viewpoint and camera intention have been checked.
- For every still image, confirm or propose framing, camera height, angle, lens/perspective behavior, subject placement, depth, and focus plane.
- For every video shot, also confirm or propose camera support, movement path, orientation, lens operation, framing evolution, focus choreography, timing, and end state.
- Give the user three interaction paths: user-described direction, two or three agent-proposed options, or a hybrid of both.
- Agent-proposed options must differ in emotional and narrative effect, not merely in terminology.
- Recommend one option and explain its visible benefit and generation risk.
- Obtain approval before building start/end-frame prompts.

## 6. Mandatory Prompt Authorization Gate

- Copy-ready image and video prompt drafting is locked by default.
- Before the first static prompt for a shot, all material fields must be decided or surfaced as explicit defaults: purpose, subject/action, shot size, composition, camera position/height/angle, lens and perspective behavior, aspect ratio, production design, lighting, palette, depth of field, focus, start state, end state and end-image decision, continuity, references, target model/mode, and generation constraints.
- For video shots, also decide support/stability, three-dimensional path, orientation, lens operation, framing evolution, focus choreography, timing/easing, subject/environmental motion, landing frame, and continuity risks.
- Present these decisions as a concise Prompt Readiness Summary. Clearly label any remaining assumption, recommended default, unresolved conflict, or high-risk instruction.
- Ask the user to approve the specification and authorize prompt drafting. Do not infer authorization from earlier approval of mood, research, a narrative route, a shot list, or one camera option.
- An unambiguous affirmative response is sufficient; do not require a password-like phrase.
- Authorization may cover one shot, a named batch, all static prompts, or all video prompts. Do not extend it beyond the stated scope.
- Static-prompt authorization does not automatically authorize final video prompts. After the actual start/end images are approved, reconfirm affected motion decisions and obtain video-prompt authorization.
- A direct request to revise an existing prompt authorizes only that requested revision, provided it does not introduce unresolved conflicts with locked decisions.

## 7. Canonical intent before model syntax

- Maintain a model-neutral production bible and canonical specification for every shot.
- Treat model prompts as compiled outputs, not the source of creative truth.
- Never silently change an approved subject, product, wardrobe, location, mood, camera rule, or continuity state to accommodate a model.
- If a model cannot reliably execute the specification, recommend a different mode, reference strategy, shot design, model, or post-production solution.

## 8. Locked invariants and controlled variables

For campaigns and sequences, explicitly separate:

- **Locked invariants:** identity, product geometry, label or logo, wardrobe, hero props, location geography, time-of-day logic, base palette, brand rules, and approved optical language.
- **Controlled variables:** shot size, angle, focal-length tendency, performance beat, camera movement, focus behavior, weather, dirt, damage, intensity, and story-driven state changes.

Only accepted, intentional changes may update the continuity state. Never propagate accidental generation drift into later prompts.

## 9. Image prompts describe a state; video prompts describe change

Static prompts prioritize:

- subject and moment;
- composition and spatial relationships;
- pose and expression;
- camera position, framing, and lens behavior;
- lighting and production design;
- material, texture, palette, atmosphere, and visual hierarchy.

Video prompts prioritize:

- start state established by the approved image;
- one primary subject action;
- one physically coherent camera behavior;
- deliberate focus behavior when needed;
- environmental motion and secondary action;
- pacing and performance;
- end state, especially when an end image is supplied;
- audio behavior only when relevant and supported.

Do not unnecessarily redescribe or destabilize visual information already locked by the input images.

## 10. Camera language must have a visible purpose

- Camera and lens names are shorthand, not substitutes for direction.
- Translate references such as ARRI, RED, Fujifilm, anamorphic, spherical, vintage glass, or film stock into the characteristics that matter: format feel, perspective, focal length, distance, depth of field, focus falloff, flare, distortion, highlight behavior, color, contrast, grain, halation, frame rate, shutter, and motion blur.
- Include only parameters that create a visible or narrative consequence.
- Define one coherent camera choreography per clip. It may combine a spatial move, pan/tilt/orbit correction, optical zoom, and focus pull when those operations belong to the same continuous intention.
- Specify camera support, 3D path, orientation, framing evolution, lens operation, focus targets and timing, speed/easing, subject relationship, and landing state whenever they matter.
- Distinguish camera movement from optical zoom and focus movement. Never use "dolly zoom" as a generic synonym for pushing in.
- Use unambiguous spatial language such as `camera-right`, `subject-right`, or `toward the right side of frame`.
- Avoid stacks of unrelated moves that would require several camera setups or create contradictory motion.
- Preserve plausible screen direction, eyelines, geography, contact, shadow direction, reflections, and physical causality.

## 11. References must have assigned jobs

- Label what each reference controls: identity, wardrobe, product, location, composition, pose, lighting, palette, texture, camera movement, performance, or sound.
- Do not attach a pile of references without explaining their relationships or priority.
- When references conflict, resolve the conflict before prompting.
- Use accepted start and end images ahead of verbal re-description whenever exact framing or continuity matters.

## 12. Anti-AI-look standard

Reject or repair outputs with:

- waxy skin, glassy eyes, or over-retouched faces;
- uniform micro-detail, oversharpening, or edge halos;
- no focus, exposure, or visual hierarchy;
- gratuitous teal-orange grading, neon saturation, bokeh, fog, particles, flare, bloom, or chromatic aberration;
- impossible reflections, shadows, contact, scale, topology, or material response;
- mutated typography, logos, packaging, controls, seams, jewelry, hands, or product geometry;
- sterile symmetry or generic production design;
- temporal morphing, sliding contact points, liquid cloth, unstable hands, random focus hunting, or continuity drift.

Treat optical imperfection as a controlled system. Prefer a coherent clean master and add strong grain, halation, aberration, or distressed texture in finishing when practical.

## 13. Research and current capabilities

- Research only when it improves current model accuracy, technical accuracy, cultural or historical authenticity, location/product fidelity, or reference analysis.
- For research-to-shotlist work, preserve sources, uncertainty, cultural considerations, and the reason each finding matters to the piece.
- Keep sources and reasoning outside copy-ready prompts.
- Verify the current Magnific model, mode, aspect ratio, duration, reference, and control options before asserting that a setting is available.
- Do not blindly use automatic prompt enhancement if it might alter approved creative or continuity decisions.

## 14. Approval and version integrity

- For campaigns, sequences, and scripts, obtain approval of the creative treatment and production bible before shot prompting.
- When Shot Research is used, obtain approval of the narrative route and proposed shot list before production-bible and shot-prompt development.
- Obtain approval of the Per-Shot Direction Check before the first static prompt for that shot.
- Obtain explicit Prompt Authorization after presenting the completed shot specification; prior approvals do not substitute for it.
- Obtain approval of static start/end frames before final video prompting.
- Identify every shot and prompt version.
- Preserve previous approved versions when revising.
- Save prompts, settings, references, acceptance criteria, and research notes as distinct sections.
