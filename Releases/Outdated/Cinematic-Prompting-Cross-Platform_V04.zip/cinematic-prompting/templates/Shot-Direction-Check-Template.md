# Per-Shot Direction Check Template

Use this before writing the first static prompt for a shot.

## Shot context

- Scene ID / Shot ID:
- Narrative purpose:
- Purpose in the final edit:
- Emotional beat:
- Approved base style or sequence override:
- Expected duration, if video:

## Direction path

Choose one:

- User describes the idea; agent translates and develops it.
- Agent proposes two or three options.
- Hybrid: user supplies part of the idea; agent completes or refines it.

## Static viewpoint check

- Shot size/composition:
- Camera height/angle:
- Lens/perspective behavior:
- Subject placement:
- Foreground/midground/background:
- Depth of field and initial focus plane:
- How this viewpoint expresses the mood and shot purpose:

## Video movement check

Complete only for video shots.

- Support/stability:
- Start frame:
- Three-dimensional path:
- Pan/tilt/roll/orbit/tracking behavior:
- Optical zoom:
- Framing evolution/parallax:
- Focus target A -> target B:
- Focus cue, speed, landing, and hold:
- Timing/easing:
- End frame:
- Generation difficulty/risk:

## Agent recommendation

- Recommended direction:
- Why it fits:
- What it makes the audience feel or notice:
- Simplest fallback if generation struggles:

## Approval

- Approved:
- Requested changes:
- Date/version:

Approval here confirms the direction but does not authorize copy-ready prompt drafting. Continue to `Prompt-Readiness-and-Authorization-Template.md`.
