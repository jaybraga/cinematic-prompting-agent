# Generic AI Chat Starter

Attach `SKILL.md` and the supporting files needed for the task, then send this message:

```text
Use the attached cinematic-prompting SKILL.md as the governing workflow for this project. Read the files it routes to before producing prompts.

Do not begin prompt drafting until we have approved the overall Direction Check and the Per-Shot Direction Check. Every video shot must begin as an approved static image, with an end image when the final state needs control. Generate one continuous camera shot per video clip with no baked-in cuts.

I will now provide my project brief, references, script, or shot list. Ask only the missing questions that could materially change the result.
```

Then paste or attach a completed copy of `templates/Project-Brief-Template.md`.

