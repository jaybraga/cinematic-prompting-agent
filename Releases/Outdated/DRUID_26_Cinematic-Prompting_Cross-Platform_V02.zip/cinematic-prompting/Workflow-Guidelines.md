# Workflow Guidelines

## Purpose of this file

This file defines the chronological execution process and deliverable structure. It relies on `Agent-Guidelines.md` for collaboration behavior and `Cinematic-Prompting-Ruleset.md` for production invariants.

## Phase 0 — Classify the assignment

Identify:

- operating mode: static shot, static-to-video shot, campaign/sequence, script breakdown, or output repair;
- source material: topic, brief, script, shot list, existing images/video, or references;
- deliverables and platform;
- intended target models and Magnific modes, if known;
- whether current factual or model-capability research is needed.

Keep the process proportional, but retain the creative-direction gate and still-first video sequence.

## Phase 1 — Parse the brief and ask only material questions

Extract what is already known, then ask one compact batch covering only missing decisions that could change the work:

1. **Purpose and audience:** desired response, message, action, placement, and viewing context.
2. **Deliverables:** still/video, shot count, duration, aspect ratio, resolution, frame rate, audio, copy, logo, and platform requirements.
3. **Mood and style:** emotional promise, realism versus stylization, references, anti-references, brand character, and intended production value.
4. **Continuity:** recurring talent, characters, products, wardrobe, props, locations, time progression, and deliberate changes.
5. **Cinematography:** shot language, format feel, lens behavior, depth of field, movement, focus, lighting, grade, and texture.
6. **Constraints:** exact brand/product details, usage rights, cultural accuracy, safety, deadline, budget, and iteration limits.

Ask what each supplied reference should control.

## Phase 2 — Direction Check

Before prompt production, present a short creative treatment for approval.

If direction is clear, return one treatment that translates the user's language into concrete visual decisions.

If direction is incomplete or contradictory, use `references/Mood-and-Style-Framework.md` to propose two or three distinct creative lanes. Put the recommended lane first. Do not continue until the user selects, combines, or redirects them.

The Direction Check must include:

- interpretation of the objective and audience;
- emotional promise and visual thesis;
- realism/stylization level;
- palette and lighting logic;
- production design and material language;
- performance and human energy;
- composition, optics, texture, and grade;
- motion and pacing principles for video;
- anti-goals and recognizable AI failure risks;
- assumptions and unresolved choices.

## Phase 3 — Build the production bible

After the Direction Check is approved, define:

- approved base look and mood;
- locked continuity invariants;
- controlled variables;
- character, product, wardrobe, location, and prop descriptions;
- reference manifest and role assignments;
- camera, lens, focus, lighting, color, texture, and movement grammar;
- scene or sequence overrides;
- target-model and generation-mode strategy;
- acceptance criteria.

For a single simple shot, this may be a compact block. For a campaign or script, make it a reusable project section.

## Phase 4 — Design the shot architecture

For every shot, define its purpose in the final edit and its narrative purpose before decorative detail.

Assign:

- scene ID and shot ID;
- narrative function and emotional beat;
- intended duration and relationship to adjacent shots;
- subject blocking, screen direction, and geography;
- composition, shot size, camera height/angle, and lens behavior;
- start state, action, and end state;
- lighting and environmental behavior;
- references and continuity carried in/out;
- whether an end frame is required.

Do not combine several continuous camera shots into one generation. Coverage is represented as separate shot IDs.

## Phase 4A — Per-Shot Direction Check

Run this gate before writing the first static prompt for each shot.

First ask the user to choose how they want to direct it:

1. **User-described:** the user explains the camera/viewpoint idea informally or technically; the agent develops and translates it.
2. **Agent-proposed:** the agent offers two or three meaningfully different options.
3. **Hybrid:** the user supplies part of the intention and the agent completes it or offers refinements.

For every still image, confirm or propose:

- shot size and composition;
- camera height and angle;
- lens/perspective behavior;
- subject placement and visual hierarchy;
- foreground, midground, and background design;
- depth of field and focus plane;
- how the viewpoint expresses the approved mood and shot function.

For every video shot, also confirm or propose:

- camera support and stability character;
- three-dimensional movement path;
- pan, tilt, roll, orbit, or subject-tracking behavior;
- optical zoom, if any;
- framing evolution and parallax;
- initial and final focus targets, cue, speed, and landing;
- timing, acceleration, deceleration, settle, and hold;
- end-frame composition and whether a separate end image is required.

When the agent proposes options, each option must state:

- a short descriptive name;
- what the audience feels or notices;
- start composition;
- camera/viewpoint behavior;
- focus behavior;
- end composition;
- generation complexity or risk;
- why it fits the shot.

Put the recommended option first. Wait for approval before Phase 5.

For a long shot list, present the checks in a compact table for batch approval. Handle hero shots, ambiguous shots, and technically complex movements individually.

## Phase 5 — Build the static shot package

Create the static prompt package before any final video prompt.

For each shot provide:

1. **Canonical static specification:** model-neutral creative intent.
2. **Start-image prompt:** copy-ready prompt adapted to the chosen image model.
3. **End-image decision:** required or not required, with a one-line reason.
4. **End-image prompt:** when required, describe the final state while preserving locked continuity.
5. **Reference bindings:** image order and what each reference controls.
6. **Magnific settings card:** model, mode, aspect ratio, resolution, reference controls, and other relevant live settings.
7. **Static acceptance criteria:** the visible conditions that make the frame usable for video.

Separate prompts from explanatory notes so they can be copied without cleanup.

For a multi-shot project, the agent may deliver all static shot prompts in one organized report, but each shot remains independent.

## Phase 6 — Static review and approval

Review generated or supplied start/end images against:

- approved mood and visual thesis;
- identity and product fidelity;
- composition and shot function;
- location geography and continuity;
- light direction, palette, material response, and texture;
- hands, typography, logos, packaging, reflections, shadows, and topology;
- start/end compatibility and plausible motion path.

For failures, recommend the smallest repair: prompt revision, reference change, localized edit, image composite, different image model, or shot redesign.

Do not write the final video prompt until the relevant static frame or frame pair is approved.

## Phase 7 — Build the single-shot video package

Read `references/Camera-Movement-Language.md`, then read the relevant model guidance in `references/Model-Adapters.md` and verify live Magnific options.

For each approved shot provide:

1. **Approved start image:** reference ID or filename.
2. **Approved end image:** reference ID or filename when used.
3. **Camera Movement Breakdown:** support, path, orientation, lens operation, framing evolution, focus choreography, timing/easing, parallax, and landing frame.
4. **Canonical motion specification:** one continuous shot, independent of model syntax.
5. **Copy-ready video prompt:** adapted to the selected model and mode, with camera and focus instructions clearly stated.
6. **Reference bindings:** what the start frame, end frame, or other references control.
7. **Magnific settings card:** model, image-to-video/start-end mode, duration, aspect ratio, resolution, audio controls, and relevant settings.
8. **Motion acceptance criteria:** performance, camera path, focus, physical behavior, and final landing state.
9. **Fallback:** the smallest alternate prompt, reference strategy, model, or post-production solution if the first approach fails.

The video prompt should describe one primary action and one coherent camera choreography. It may combine spatial movement, orientation, lens operation, and focus movement when their timing and relationship are clear. It must not request cuts, coverage changes, or a montage.

## Phase 8 — Generation QC and continuity update

When visual generation becomes part of the workflow:

- compare the actual output with the canonical specification;
- classify it as accepted, repairable, or rejected;
- use targeted intra-shot repair for local failures;
- update future shots only with accepted intentional state changes;
- do not propagate accidental drift;
- log model, mode, prompt version, settings, references, generation ID, and decision.

Keep temporal repair separate from final upscaling and finishing.

## Phase 9 — Deliver and save the report

Use this report order:

1. Project metadata and version.
2. Approved Direction Check.
3. Production bible.
4. Reference manifest.
5. Shot index.
6. Approved Per-Shot Direction Checks.
7. Static shot packages.
8. Static approval/QC notes.
9. Single-shot video packages, added only after static approval.
10. Global and shot-specific avoidance rules.
11. Revision/generation log.
12. Research sources and notes, separate from prompts.

Save project reports in the user-specified project folder. Do not mix temporary drafts with final deliverables.

## File naming

Use this grammar unless the user specifies another convention:

`DRUID_YY_Client_Project-Name_Deliverable_Version.ext`

Examples:

- `DRUID_26_GOL_Insignia-Launch_Shot-Prompts_V01.md`
- `DRUID_26_Client_Project-Name_SC03-SH02_Start-Frame_A.png`
- `DRUID_26_Client_Project-Name_SC03-SH02_End-Frame_A.png`
- `DRUID_26_Client_Project-Name_SC03-SH02_Video_V02.mp4`

Use underscores to separate naming sections and hyphens within a section. Use stable scene/shot IDs and alphabetic suffixes for creative variants.
